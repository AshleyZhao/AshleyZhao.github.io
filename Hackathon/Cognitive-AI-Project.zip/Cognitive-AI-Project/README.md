# Cognitive-AI-Project
A cognitive AI project using Watson API for the 2018 IBM Hackathon.

## Contributers:

Amy Li, Ashley Zhao, Brianna Li, Steven Wan, Tommy Wojtczak 
