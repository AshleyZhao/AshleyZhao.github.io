from __future__ import print_function
import re
import json
import os
from os.path import join, dirname
from Tkinter import *
from watson_developer_cloud import PersonalityInsightsV3, VisualRecognitionV3

'''
This function walks through the directory where all the user photos are stored, and call the Watson VisualRecognitionV3 service to infer the users' basic info (age, gender, etc).
It outputs the inference results to another location, from where they'll be utilized by the matching functions later.
'''
def inferVisualRecong():
	
	# Authenticate
	visual_recognition = VisualRecognitionV3(
		'2016-05-20', 
		iam_api_key="-alHoLiyXC3XsVl8CaF7qE555iSFeNoCnQ8Oed2IfDaE")
	
	# For each photos in the directory
	for path, subdirs, files in os.walk(r'resources/photo/'):
		for filename in files:
			face_path = join(dirname(__file__), 'resources/photo/' + filename)
			# Send the request to Watson VisualRecognitionV3
			with open(face_path, 'rb') as image_file:
				face_result = visual_recognition.detect_faces(images_file=image_file)
			
			# Process and store the data returned from Watson VisualRecognitionV3
			output = json.dumps(face_result, indent=2)
			username = os.path.splitext(filename)[0]
			username += 'Basic'
			with open('./outputphoto/' + username + '.txt', 'w') as f:
				f.write(output)	
			
'''
This function walks through the directory where all the user descriptions are stored, and call the Watson PersonalityInsightsV3 service to infer the users major facets.
It outputs the inference results to another location, from where they'll be utilized by the matching functions later.
'''
def inferPersonality():

	# Authenticate
    personality_insights = PersonalityInsightsV3(
        version='2016-10-20',
        username='2592d405-7da0-4be2-a28a-935991226186',
        password='lfW2kLd7xumH')
	
	# For each descriptions (in json file) in the directory
    for path, subdirs, files in os.walk(r'resources/description/'):
        for filename in files:
			# Send the request to Watson PersonalityInsightsV3
            with open(join(dirname(__file__), './resources/description/' + filename)) as \
                    profile_json:
                profile = personality_insights.profile(
                    profile_json.read(), content_type='application/json',
                    raw_scores=True, consumption_preferences=True)

			# Process and store the data returned from Watson PersonalityInsightsV3
            output = json.dumps(profile, indent=2)
            username = os.path.splitext(filename)[0]
            with open('./output/' + username + '.txt', 'w') as f:
                f.write(output)

'''
This function takes in two user names as the input, and based on each users' basic info (from inferVisualRecong),
it decides whether or not those two users could potentially match, and can go to further matching processes
This function returns a boolean that states pass or not
'''
def matchTwoBasic(user1, user2):
	try:
		file1 = open('./outputphoto/' + user1 + 'Basic.txt', "r")
		file2 = open('./outputphoto/' + user2 + 'Basic.txt', "r")

	except IOError:
		raise
	else:
		output1 = file1.read()
		output2 = file2.read()

		face_result_1 = json.loads(output1)
		face_result_2 = json.loads(output2)

		max_age_1 = face_result_1["images"][0]["faces"][0]["age"]["max"]
		min_age_1 = face_result_1["images"][0]["faces"][0]["age"]["min"]
		avg_age_1 = (max_age_1 + min_age_1) / 2.0
		print('age of user1 is')
		print(avg_age_1)

		max_age_2 = face_result_2["images"][0]["faces"][0]["age"]["max"]
		min_age_2 = face_result_2["images"][0]["faces"][0]["age"]["min"]
		avg_age_2 = (max_age_2 + min_age_2) / 2.0
		print('age of user2 is')
		print(avg_age_2)

		matchBasic = False
		if abs(avg_age_1 - avg_age_2) < 10:
			matchBasic = True

		return matchBasic
		
'''
This function takes in two user names as the input, and based on each users' basic info (from inferVisualRecong) and characteristics (from inferPersonality), 
this function will decide whether or not the two users match with each other.
It then output the result:
1. number of similar facets if match, and
2. a message if not match
'''				
def matchTwo(user1, user2):
	try:
		if matchTwoBasic(user1, user2):
			try:
				file1 = open ('./output/'+user1+'.txt', "r")
				file2 = open ('./output/'+user2+'.txt', "r")
			except IOError:
				print ('No profile found')
				matches = 'No profile found'
			else:
				output1 = file1.read()
				output2 = file2.read()

				try:
					for line in output1:
						needs1 = re.findall('need_(.+?)\"', output1)
				except AttributeError:
					needs1 = 'no needs founded'

				try:
					for line in output2:
						needs2 = re.findall('need_(.+?)\"', output2)
				except AttributeError:
					needs2 = 'no needs founded'

				try:
					for line in output1:
						facet1 = re.findall('facet_(.+?)\"', output1)
				except AttributeError:
					facet1 = 'no facet founded'

				try:
					for line in output2:
						facet2 = re.findall('facet_(.+?)\"', output2)
				except AttributeError:
					facet2 = 'no facet founded'

				matches1 = set(needs1) & set(needs2)
				matches2 = set(facet1) & set(facet2)

				matches = len(matches1) + len(matches2)

				return matches
		else:
			return 'Not match'
	except IOError:
		print ('No profile found')

'''
This function takes in only one user name as the input, and based on other users' basic info (from inferVisualRecong) and characteristics (from inferPersonality) stored previously, 
this function will find out the best match for the input user.
It then output the best match user name as the result
'''
def matchSearch(user1):
    max = 0
    bestMatch = ''
    for path, subdirs, files in os.walk(r'output/'):
        for filename in files:
            if filename.endswith(".txt") & (filename!=(user1 + '.txt')):
				user2 = os.path.splitext(filename)[0]
				numMatch = matchTwo(user1, user2)
				if numMatch > max:
					max = numMatch
					bestMatch = user2
    return bestMatch

inferPersonality()
inferVisualRecong()

print("If user1 and user2 matches with each other:")

numMatch = matchTwo("male","female")

print ('number of personality matches:')
print(numMatch)
print(" ")
print("Find the best match for user1")

match = matchSearch("male")

print("name of the match:")
print(match)

#pop up window for result
top = Tk()
top.title("Matching Information")
name= Label(top,text= match)
number=Label(top,text= numMatch)

top.geometry("1000x1000")
photo=PhotoImage(file="match.jpg")
label=Label(top,image=photo)
name.config(width=200)
name.config(font=("Courier", 100))
number.config(width=200)
number.config(font=("Courier", 100))
name.pack()
number.pack()
label.pack()

top.mainloop()
